using System.Net;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using ReqRes.Application.DTOs;
using ReqRes.Infrastructure.Config;
using ReqRes.Infrastructure.Services;
using Sentry;

namespace ReqRes.Tests;
public class ExternalUserServiceTests
{
    [Fact]
    public async Task GetUserByIdAsync_ReturnsUser()
    {
        // Arrange
        var userId = 2;
        var expectedUser = new UserDto
        {
            Id = 2,
            Email = "janet.weaver@reqres.in",
            First_Name = "Janet",
            Last_Name = "Weaver",
            
        };

        var apiResponse = new
        {
            data = expectedUser
        };

        var json = JsonConvert.SerializeObject(apiResponse);

        var handlerMock = new Mock<HttpMessageHandler>();
        handlerMock.Protected()
            .Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>()
            )
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent(json)
            });

        var httpClient = new HttpClient(handlerMock.Object)
        {
            BaseAddress = new Uri("https://reqres.in/api/")
        };

        var memoryCache = new MemoryCache(new MemoryCacheOptions());

        var optionsMock = new Mock<IOptions<ReqResApiSettings>>();
        optionsMock.Setup(x => x.Value).Returns(new ReqResApiSettings
        {
            BaseUrl = "https://reqres.in/api/"
        });

        var service = new ExternalUserService(httpClient, memoryCache, optionsMock.Object);

        // Act
        var result = await service.GetUserByIdAsync(userId);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(expectedUser.Id, result.Id);
        Assert.Equal(expectedUser.Email, result.Email);
        Assert.Equal(expectedUser.First_Name, result.First_Name);
        Assert.Equal(expectedUser.Last_Name, result.Last_Name);
    }
}
