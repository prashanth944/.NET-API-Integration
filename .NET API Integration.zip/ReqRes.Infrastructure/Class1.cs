﻿namespace ReqRes.Infrastructure;

public class Class1
{

}
