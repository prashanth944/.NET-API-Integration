﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReqRes.Infrastructure.Config
{
    public class ReqResApiSettings
    {
        public string BaseUrl { get; set; }
        public int CacheDurationSeconds { get; set; } = 60;
    }
}
