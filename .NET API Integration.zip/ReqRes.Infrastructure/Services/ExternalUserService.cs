﻿using System.Net.Http.Json;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using Polly;
using Polly.Extensions.Http;
using ReqRes.Application.DTOs;
using ReqRes.Application.Interfaces;
using ReqRes.Infrastructure.Config;

namespace ReqRes.Infrastructure.Services
{
    public class ExternalUserService : IExternalUserService
    {
        private readonly HttpClient _httpClient;
        private readonly IMemoryCache _cache;
        private readonly ReqResApiSettings _settings;

        public ExternalUserService(HttpClient httpClient, IMemoryCache cache, IOptions<ReqResApiSettings> settings)
        {
            _httpClient = httpClient;
            _cache = cache;
            _settings = settings.Value;
        }

        public async Task<UserDto> GetUserByIdAsync(int userId)
        {
            string cacheKey = $"user_{userId}";
            if (_cache.TryGetValue(cacheKey, out UserDto cachedUser))
                return cachedUser;

            var response = await _httpClient.GetAsync($"users/{userId}");
            if (!response.IsSuccessStatusCode)
                throw new HttpRequestException($"Error: {response.StatusCode}");

            var json = await response.Content.ReadFromJsonAsync<ApiSingleUserResponse>();

            var user = new UserDto
            {
                Id = json.Data.Id,
                Email = json.Data.Email,
                First_Name = json.Data.First_Name,
                Last_Name = json.Data.Last_Name
            };

            _cache.Set(cacheKey, user, TimeSpan.FromSeconds(_settings.CacheDurationSeconds));
            return user;
        }

        public async Task<IEnumerable<UserDto>> GetAllUsersAsync()
        {
            List<UserDto> allUsers = new();
            int page = 1;
            bool hasMore;

            do
            {
                var response = await _httpClient.GetAsync($"users?page={page}");
                if (!response.IsSuccessStatusCode)
                    throw new HttpRequestException($"Error: {response.StatusCode}");

                var json = await response.Content.ReadFromJsonAsync<ApiUserResponse>();

                allUsers.AddRange(json.Data.Select(u => new UserDto
                {
                    Id = u.Id,
                    Email = u.Email,
                    First_Name = u.First_Name,
                    Last_Name = u.Last_Name
                }));

                hasMore = page < json.Total_Pages;
                page++;
            }
            while (hasMore);

            return allUsers;
        }

        private class ApiUserResponse
        {
            public List<UserDto> Data { get; set; }
            public int Total_Pages { get; set; }
        }

        private class ApiSingleUserResponse
        {
            public UserDto Data { get; set; }
        }
    }

}
