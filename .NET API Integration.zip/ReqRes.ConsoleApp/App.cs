﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using ReqRes.Application.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReqRes.ConsoleApp
{
    public class App
    {
        private readonly IExternalUserService _userService;

        public App(IExternalUserService userService)
        {
            _userService = userService;
        }

        public async Task Run()
        {
            // Call your external user service here
            var result = await _userService.GetAllUsersAsync();
            Console.WriteLine(result);
        }
        //public static async Task RunConsoleApp(this IHost host)
        //{
        //    using var scope = host.Services.CreateScope();
        //    var service = scope.ServiceProvider.GetRequiredService<IExternalUserService>();

        //    var user = await service.GetUserByIdAsync(2);
        //    Console.WriteLine($"User 2: {user.First_Name} {user.Last_Name}");

        //    var allUsers = await service.GetAllUsersAsync();
        //    Console.WriteLine($"Fetched {allUsers.Count()} users.");
        //}
    }

}
