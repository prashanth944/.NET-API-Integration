﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Polly;
using Polly.Extensions.Http;
using System.Net.Http;
using System;
using ReqRes.Application.Interfaces;
using ReqRes.Infrastructure.Config;
using ReqRes.Infrastructure.Services;
using ReqRes.ConsoleApp;

class Program
{
    static async Task Main(string[] args)
    {
        var host = Host.CreateDefaultBuilder(args)
            .ConfigureServices((context, services) =>
            {
                services.Configure<ReqResApiSettings>(context.Configuration.GetSection("ReqResApi"));

                services.AddMemoryCache();
                

                services.AddHttpClient<IExternalUserService, ExternalUserService>((sp, client) =>
                {
                    var settings = sp.GetRequiredService<IOptions<ReqResApiSettings>>().Value;
                    client.BaseAddress = new Uri(settings.BaseUrl);
                })
                .AddPolicyHandler(GetRetryPolicy());

                // Optionally register your console app entry point
                services.AddTransient<App>();
            })
            .ConfigureAppConfiguration((context, config) =>
            {
                config.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
            })

            .Build();

        // Resolve the App class and run the logic
        var app = host.Services.GetRequiredService<App>();
        await app.Run();
    }

    static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy()
    {
        return HttpPolicyExtensions
            .HandleTransientHttpError()
            .WaitAndRetryAsync(3, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));
    }
}
