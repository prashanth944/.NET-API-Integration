﻿namespace ReqRes.Application;

public class Class1
{

}
